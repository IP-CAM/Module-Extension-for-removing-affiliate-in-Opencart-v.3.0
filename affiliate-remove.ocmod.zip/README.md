# affiliate-remove.ocmod
Opencart 3.0 module extension for removing affiliate

> ## usage
>
>  1. remove affiliate link on footer
>  2. redirect affiliate related page to home

>## install steps
> 1. go to admin page
> 2. go to Extensions > Installer, upload affiliate-remove.ocmod.zip.
> 3. go to Extensions > Modifications, click refresh button on the top right.
> 4. go to Extensions > Extensions, Choose the extension type "Modules", install Affiliate Remove Module and change status to enabled
  
> This extension is totally free and that would be good, if you found this is helpful and not hesitated to support me, please send me some ETH to: 0xE37Ce7310ff57641A3e9D8416860B96ca3d6f2A4
> ![0xE37Ce7310ff57641A3e9D8416860B96ca3d6f2A4](https://github.com/codefishcode/affiliate-remove.ocmod/blob/master/eth_qrcode.png)
>
> Bug Report are always welcome too :P